﻿using ElKibambo;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CSharp
{
    public partial class Form1 : Form
    {
        Kibambo kibambo = null;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            LoadPersons();
            InitializeKibambo();
        }

        private void LoadPersons()
        {
            // Adding columns
            dgvPersons.Columns.Add("registration_number", "Reg. number");
            dgvPersons.Columns.Add("first_name", "First name");
            dgvPersons.Columns.Add("last_name", "Last name");
            dgvPersons.Columns.Add("age", "Age");

            // "Person" objects to display in the data grid
            var persons = new List<Person>
            {
                new Person("0001", "Michael", "Kyungu Ilunga", 21),
                new Person("0002", "Emmanuel", "Ilunga Ndalamba", 25),
                new Person("0003", "Jonathan", "Mulimbi Somwe", 22),
                new Person("0004", "Gloria", "Ngombe Kibambo", 20),
                new Person("0005", "Achille", "Mutombo Mubakilay", 22),
                new Person("0006", "Marc", "Kyalika Musomena", 23),
                new Person("0007", "Martin", "Manama Kabeya", 26),
                new Person("0008", "Ornellah", "Masengo Mutoni", 20),
                new Person("0009", "Elie", "Ebukeya Tshombe", 22),
                new Person("0010", "Françoise", "Ebukeya Lukonde", 15),
                new Person("0011", "Hansvané", "Kashala Kahilu", 23),
                new Person("0012", "Benoit", "Kamona Bunake", 23),
                new Person("0013", "Samuel", "Ngandu Mwepu", 21),
                new Person("0014", "Jules", "Malemo Miyayo", 23),
                new Person("0015", "Rachel", "Wany Mukanire", 23)
            };

            // Adding data in the data grid
            foreach (Person person in persons)
            {
                dgvPersons.Rows.Add(
                    person.RegistrationNumber,
                    person.FirstName,
                    person.LastName,
                    person.Age
                );
            }
        }

        private void InitializeKibambo()
        {
            kibambo = new Kibambo(dgvPersons, dgvSearch, true)
            {
                Columns = new KibamboColumn[]
                {
                    new KibamboColumn("registration_number", "Reg. number")
                    {
                        Operators = new[] { "==", "!=" }
                    },

                    new KibamboColumn("age", "Age", KibamboColumnType.Numeric, "Integer", new string[] { "==", "<", ">", "<=", ">=", "!=" })
                },

                SearchHandler = delegate (DataGridViewRow row)
                {
                    // We choose to make the lines that have not satisfied the search criteria invisible.
                    // But you can also do something else, for example change color, etc.
                    row.Visible = false;
                },

                CancelSearchHandler = delegate (DataGridViewRow row)
                {
                    // As the lines were hidden during the search, it seems logical that we can re-show them when deciding to cancel a search made.
                    // We must therefore put the line to its initial state before the search.
                    row.Visible = true;
                },

                TitleField = "Field",
                TitleOperator = "Operator",
                TitleType = "Type",
                TitleValue = "Value"
            };

            kibambo.Initialize();
        }

        private void btnShowAll_Click(object sender, EventArgs e)
        {
            kibambo.CancelSearch();
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            try
            {
                kibambo.Search();
            }

            catch (KibamboException ex)
            {
                switch (ex.ErrorCode)
                {
                    case KibamboErrorCode.ValueMustBeNumeric:
                        MessageBox.Show("You must enter a numeric type value for the numeric column !", "Input error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        break;

                    default:
                        MessageBox.Show("An error occured during the search. The error message is " + ex.Message + " !", "Error during search", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        break;
                }
            }
        }
    }
}
