﻿Imports ElKibambo
Public Class Form1
    Dim kibambo As Kibambo
    Private Sub btnShowAll_Click(sender As Object, e As EventArgs) Handles btnShowAll.Click
        kibambo.CancelSearch()
    End Sub
    Private Sub btnSearch_Click(sender As Object, e As EventArgs) Handles btnSearch.Click
        Try
            kibambo.Search()
        Catch ex As KibamboException
            Select Case ex.ErrorCode
                Case KibamboErrorCode.ValueMustBeNumeric
                    MessageBox.Show("You must enter a numeric type value for the numeric column !", "Input error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Case Else
                    MessageBox.Show("An error occured during the search. The error message is " + ex.Message + " !", "Error during search", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Select
        End Try
    End Sub
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        AddColumnsDgvPersons()
        LoadData()
        InitializeKibambo()
    End Sub
    Private Sub AddColumnsDgvPersons()
        dgvPersons.Columns.Add("registration_number", "Reg. number")
        dgvPersons.Columns.Add("first_name", "First name")
        dgvPersons.Columns.Add("last_name", "Last name")
        dgvPersons.Columns.Add("age", "Age")
    End Sub
    Private Sub LoadData()
        dgvPersons.Rows.Add("0001", "Michael", "Kyungu Ilunga", 21)
        dgvPersons.Rows.Add("0002", "Emmanuel", "Ilunga Ndalamba", 25)
        dgvPersons.Rows.Add("0003", "Jonathan", "Mulimbi Somwe", 22)
        dgvPersons.Rows.Add("0004", "Gloria", "Ngombe Kibambo", 20)
        dgvPersons.Rows.Add("0005", "Achille", "Mutombo Mubakilay", 22)
        dgvPersons.Rows.Add("0006", "Marc", "Kyalika Musomena", 23)
        dgvPersons.Rows.Add("0007", "Martin", "Manama Kabeya", 26)
        dgvPersons.Rows.Add("0008", "Ornellah", "Masengo Mutoni", 20)
        dgvPersons.Rows.Add("0009", "Elie", "Ebukeya Tshombe", 22)
        dgvPersons.Rows.Add("0010", "Françoise", "Ebukeya Lukonde", 15)
        dgvPersons.Rows.Add("0011", "Hansvané", "Kashala Kahilu", 23)
        dgvPersons.Rows.Add("0012", "Benoit", "Kamona Bunake", 23)
        dgvPersons.Rows.Add("0013", "Samuel", "Ngandu Mwepu", 21)
        dgvPersons.Rows.Add("0014", "Jules", "Malemo Miyayo", 23)
        dgvPersons.Rows.Add("0015", "Rachel", "Wany Mukanire", 23)
    End Sub
    Private Sub Search(row As DataGridViewRow)
        ' We choose to make the lines that have not satisfied the search criteria invisible.
        ' But you can also do something else, for example change color, etc.
        row.Visible = False
    End Sub
    Private Sub ShowAll(row As DataGridViewRow)
        ' As the lines were hidden during the search, it seems logical that we can re-show them when deciding to cancel a search made.
        ' We must therefore put the line to its initial state before the search.
        row.Visible = True
    End Sub
    Private Sub InitializeKibambo()
        Dim kibamboColumnMatricule As New KibamboColumn("registration_number", "Reg. number")
        kibamboColumnMatricule.Operators = {"==", "!="}

        Dim kibamboColumnAge As New KibamboColumn("age", "Age")
        kibamboColumnAge.Operators = {"==", "<", ">", "<=", ">=", "!="}

        kibambo = New Kibambo(
            dgvPersons,
            dgvSearch,
            New KibamboColumn() {
                kibamboColumnMatricule,
                kibamboColumnAge
            },
            AddressOf Search,
            AddressOf ShowAll,
            True
        )

        kibambo.Initialize()
    End Sub
End Class
