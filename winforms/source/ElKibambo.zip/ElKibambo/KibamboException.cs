﻿using System;
using System.Resources;

namespace ElKibambo
{
    /// <summary>
    /// In the event of an error, El Kibambo triggers exceptions of this type. 
    /// </summary>
    /// <summary lang="fr">
    /// En cas d’erreur, El Kibambo déclenche des exceptions de ce type. 
    /// </summary>
    public class KibamboException : Exception
    {
        /// <summary>
        /// Provides a detailing message.
        /// </summary>
        /// <summary lang="fr">
        /// Fournit un message détaillant l’erreur.
        /// </summary>
        public new string Message { get; private set; }

        /// <summary>
        /// This property contains the error code, which is of type <c>KibamboErrorCode</c>.
        /// </summary>
        /// <summary lang="fr">
        /// Cette propriété contient le code d’erreur, qui est de type <c>KibamboErrorCode</c>.
        /// </summary>
        public KibamboErrorCode ErrorCode { get; private set; }

        /// <summary>
        /// A single constructor of the <c>KibamboException</c> class that takes the error type as an argument.
        /// </summary>
        /// <param name="errorCode">The type of error that occurred.</param>
        /// <summary lang="fr">
        /// Constructeur unique de la classe <c>KibamboException</c> prenant en argument le type d'erreur.
        /// </summary>
        /// <param name="errorCode" lang="fr">Le type d'erreur ayant survenu.</param>
        public KibamboException(KibamboErrorCode errorCode)
        {
            ErrorCode = errorCode;

            var ress = new ResourceManager("ElKibambo.strings", typeof(KibamboException).Assembly);

            switch (ErrorCode) 
            {
                case KibamboErrorCode.ColumnsNotSpecified:
                    Message = ress.GetString("columnsNotSpecified");
                    break;
                     
                case KibamboErrorCode.ColumnNotRecognized:
                    Message = ress.GetString("columnNotRecognized");
                    break;

                case KibamboErrorCode.ValueMustBeNumeric :
                    Message = ress.GetString("valueMustBeNumeric");
                    break;

                case KibamboErrorCode.OperatorNotRecognized:
                    Message = ress.GetString("operatorNotRecognized");
                    break;

                case KibamboErrorCode.ComparisonTypeNotRecognized:
                    Message = ress.GetString("comparisonTypeNotRecognized");
                    break;

                case KibamboErrorCode.MoreColumnsThanDgvData:
                    Message = ress.GetString("moreColumnsThanDgvData");
                    break;

                case KibamboErrorCode.DgvOfDataMustBeDifferentThanDgvOfSearch:
                    Message = ress.GetString("dgvOfDataMustBeDifferentThanDgvOfSearch");
                    break;

                case KibamboErrorCode.YouMustSpecifyAtLeastOneOperator:
                    Message = ress.GetString("youMustSpecifyAtLeastOneOperator");
                    break;

                default: throw new InvalidOperationException(ress.GetString("defaultErrorMessage"));
            }
        }

        /// <summary>
        /// Describes the exception that occurred.
        /// </summary>
        /// <summary lang="fr">
        /// Décrit l'exception qui est survenue.
        /// </summary>
        public override string ToString()
        {
            return base.ToString() + Environment.NewLine + new ResourceManager("ElKibambo.strings", typeof(Kibambo).Assembly).GetString("errorMessage") + " : " + Message;
        }
    }

    /// <summary>
    /// <c>KibamboErrorCode</c> gives us more details about the type of error.
    /// </summary>
    /// <summary lang="fr">
    /// <c>KibamboErrorCode</c> nous donne plus de précisions sur le type d’erreur.
    /// </summary>
    public enum KibamboErrorCode
    {
        /// <summary>
        /// Error triggered in case El Kibambo cannot find a column. 
        /// </summary>
        /// <summary lang="fr">
        /// Erreur déclenchée au cas où El Kibambo n’arrive pas à retrouver une colonne. 
        /// </summary>
        ColumnNotRecognized = 5,

        /// <summary>
        /// Error due to the fact that we did not specify columns when building the <c>Kibambo</c> object and the <c>Kibambo.AutoCompleteColumns</c> property is <c>false</c>.
        /// </summary>
        /// <summary lang="fr">
        /// Erreur due au fait que nous n’avons pas spécifié des colonnes lors de la construction de l’objet <c>Kibambo</c> et que la propriété <c>Kibambo.AutoCompleteColumns</c> vaut <c>false</c>.
        /// </summary>
        ColumnsNotSpecified = 10,

        /// <summary>
        /// Error due to the fact that El Kibambo cannot determine the type of comparison.
        /// </summary>
        /// <summary lang="fr">
        /// Erreur due au fait qu’El Kibambo n’arrive pas à déterminer le type de comparaison.
        /// </summary>
        ComparisonTypeNotRecognized = 15,

        /// <summary>
        /// Error due to the fact that we pass the same <c>DataGridView</c> as the grid containing the data and also as a search grid when instantiating the <c>Kibambo</c> object. 
        /// </summary>
        /// <summary lang="fr">
        /// Erreur due au fait que nous passions un même <c>DataGridView</c> comme grille contenant les données et aussi comme grille de recherche lors de l’instanciation de l’objet <c>Kibambo</c>. 
        /// </summary>
        DgvOfDataMustBeDifferentThanDgvOfSearch = 20,

        /// <summary>
        /// Occurs if we pass more <c>KibamboColumn</c> objects to the <c>Kibambo</c> object than the grid containing the data actually contains.
        /// </summary>
        /// <summary lang="fr">
        /// Survient si nous passons plus d’objets <c>KibamboColumn</c> à l’objet <c>Kibambo</c> que n’en contient réellement la grille contenant les données.
        /// </summary>
        MoreColumnsThanDgvData = 25,

        /// <summary>
        /// Error occurring in the event that El Kibambo cannot recognize the comparison operator during the search. 
        /// </summary>
        /// <summary lang="fr">
        /// Erreur survenant dans le cas où El Kibambo n’arrive pas à reconnaitre l’operateur de comparaison lors de la recherche. 
        /// </summary>
        OperatorNotRecognized = 30,

        /// <summary>
        /// Error caused by the user entering a non-numeric value for a numeric column. 
        /// </summary>
        /// <summary lang="fr">
        /// Erreur due au fait que l’utilisateur saisit une valeur non numérique pour une colonne de type numérique. 
        /// </summary>
        ValueMustBeNumeric = 35,

        /// <summary>
        /// Occurs if we pass an empty array for operators when building a <c>KibamboColumn</c> object.
        /// </summary>
        /// <summary lang="fr">
        /// Survient si nous passons un tableau vide pour les opérateurs lors de la construction d’un objet <c>KibamboColumn</c>.
        /// </summary>
        YouMustSpecifyAtLeastOneOperator = 40
    }
}                  
