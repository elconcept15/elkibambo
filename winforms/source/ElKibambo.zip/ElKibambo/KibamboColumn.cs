﻿using System.Linq;
using System.Resources;

namespace ElKibambo
{
    /// <summary>
    /// A class that is used to represent each column in the grid containing the data. 
    /// </summary>
    /// <summary lang="fr">
    /// Classe qui permet de représenter chaque colonne de la grille contenant les données. 
    /// </summary>
    public class KibamboColumn
    {
        #region attributs 

        private string _name;
        private string _header;
        private KibamboColumnType _columnType;
        private string _headerColumnType;
        private string[] _operators = SupportedOperators;

        #endregion

        #region constantes 

        /// <summary>
        /// Static, read-only property giving operators supported by El Kibambo.
        /// </summary>
        /// <summary lang="fr">
        /// Propriété statique, en lecture seule donnant les opérateurs pris en charge par El Kibambo.
        /// </summary>
        public static readonly string[] SupportedOperators = { "==", "<", ">", "<=", ">=", "!=", "LIKE" };

        #endregion

        #region propriétés 

        /// <summary>
        /// Refers to the <c>DataGridViewColumn.Name</c> property of the grid column containing the data that the KibamboColumn object represents. 
        /// </summary>
        /// <summary lang="fr">
        /// Fait référence à la propriété <c>DataGridViewColumn.Name</c> de la colonne de la grille contenant les données que l’objet KibamboColumn représente. 
        /// </summary>
        public string Name
        {
            get
            {
                return _name;
            }

            set
            {
                _name = value;
            }
        }

        /// <summary>
        /// Name of the column, and which will be displayed by El Kibambo. 
        /// </summary>
        /// <summary lang="fr">
        /// Nom de la colonne, et qui sera affiché par El Kibambo. 
        /// </summary>
        public string Header
        {
            get
            {
                return _header;
            }

            set
            {
                _header = value;
            }
        }

        /// <summary>
        /// The type of the column. 
        /// </summary>
        /// <summary lang="fr">
        /// Type de la colonne. 
        /// </summary>
        public KibamboColumnType ColumnType
        {
            get
            {
                return _columnType;
            }

            set
            {
                _columnType = value;
            }
        }

        /// <summary>
        /// The type of column to be displayed by El Kibambo in the search grid.
        /// </summary>
        /// <summary lang="fr">
        /// Type de colonne à afficher par El Kibambo dans la grille de recherche.
        /// </summary>
        public string HeaderColumnType
        {
            get
            {
                return _headerColumnType;
            }

            set
            {
                _headerColumnType = value;
            }
        }

        /// <summary>
        /// The table of comparison operator signs to use for the column.
        /// </summary>
        /// <summary lang="fr">
        /// Tableau des signes d’opérateurs de comparaison à utiliser pour la colonne.
        /// </summary>
        public string[] Operators
        {
            get
            {
                return _operators;
            }

            set
            {
                if (value.Length == 0)
                {
                    throw new KibamboException(KibamboErrorCode.YouMustSpecifyAtLeastOneOperator);
                }

                foreach (string op in value)
                {
                    if(op == null || SupportedOperators.Contains(op.Trim()) == false)
                    {
                        throw new KibamboException(KibamboErrorCode.OperatorNotRecognized);
                    }
                }

                _operators = value;
            }
        }

        #endregion

        #region constructeurs 

        /// <summary>
        /// Initializes an object by specifying just the internal name of the column and its title.
        /// </summary>
        /// <param name="name">The value to assign in the <c>KibamboColumn.Name</c> property.</param>
        /// <param name="header">The value to assign in the <c>KibamboColumn.Header</c> property.</param>
        /// <summary lang="fr">
        /// Initialise un objet <c>KibamboColumn</c> en spécifiant juste le nom interne de la colonne et son intitulé.
        /// </summary>
        /// <param name="name" lang="fr">Valeur à affecter dans la propriété <c>KibamboColumn.Name</c>.</param>
        /// <param name="header" lang="fr">Valeur à affecter dans la propriété <c>KibamboColumn.Header</c>.</param>
        public KibamboColumn(string name, string header)
        {
            Name = name;
            Header = header;

            ColumnType = KibamboColumnType.String;
            HeaderColumnType = new ResourceManager("ElKibambo.strings", typeof(KibamboColumn).Assembly).GetString("headerColumnTypeStr");
        }

        /// <summary>
        /// Initializes a <c>KibamboColumn</c> object by specifying just the internal name of the column and its title.
        /// </summary>
        /// <param name="name">The value to assign in the <c>KibamboColumn.Name</c> property.</param>
        /// <param name="columnType">The value to assign in the <c>KibamboColumn.ColumnType</c> property.</param>
        /// <summary lang="fr">
        /// Initialise un objet <c>KibamboColumn</c> en spécifiant juste le nom interne de la colonne et son intitulé.
        /// </summary>
        /// <param name="name" lang="fr">Valeur à affecter dans la propriété <c>KibamboColumn.Name</c>.</param>
        /// <param name="columnType" lang="fr">Valeur à affecter dans la propriété <c>KibamboColumn.ColumnType</c>.</param>
        public KibamboColumn(string name, KibamboColumnType columnType)
        {
            Name = name;
            Header = null;

            ColumnType = columnType;

            switch (ColumnType)
            {
                case KibamboColumnType.Numeric:
                    HeaderColumnType = new ResourceManager("ElKibambo.strings", typeof(KibamboColumn).Assembly).GetString("headerColumnTypeInt");
                    break;

                case KibamboColumnType.String:
                    HeaderColumnType = new ResourceManager("ElKibambo.strings", typeof(KibamboColumn).Assembly).GetString("headerColumnTypeStr");
                    break;
            }
        }

        /// <summary>
        /// Initializes a <c>KibamboColumn</c> object by specifying the column's internal name, column title, and column type.
        /// </summary>
        /// <param name="name">The value to assign in the property <c>KibamboColumn.Name</c>.</param>
        /// <param name="header">The value to assign in the property <c>KibamboColumn.Header</c>.</param>
        /// <param name="columnType">The value to assign in the property <c>KibamboColumn.ColumnType</c>.</param>
        /// <summary lang="fr">
        /// Initialise un objet <c>KibamboColumn</c> en spécifiant le nom interne de la colonne, l'intitulé de la colonne, et le type de la colonne.
        /// </summary>
        /// <param name="name" lang="fr">Valeur à affecter dans la propriété <c>KibamboColumn.Name</c>.</param>
        /// <param name="header" lang="fr">Valeur à affecter dans la propriété <c>KibamboColumn.Header</c>.</param>
        /// <param name="columnType" lang="fr">Valeur à affecter dans la propriété <c>KibamboColumn.ColumnType</c>.</param>
        public KibamboColumn(string name, string header, KibamboColumnType columnType) : this(name, header)
        {
            ColumnType = columnType;

            switch(ColumnType)
            {
                case KibamboColumnType.Numeric:
                    HeaderColumnType = new ResourceManager("ElKibambo.strings", typeof(KibamboColumn).Assembly).GetString("headerColumnTypeInt");
                    break;

                case KibamboColumnType.String:
                    HeaderColumnType = new ResourceManager("ElKibambo.strings", typeof(KibamboColumn).Assembly).GetString("headerColumnTypeStr");
                    break;
            }
        }

        /// <summary>
        /// Initializes a <c>KibamboColumn</c> object by specifying the column's internal name, column title, column type, and column type title.
        /// </summary>
        /// <param name="name">The value to assign in the property <c>KibamboColumn.Name</c>.</param>
        /// <param name="header">The value to assign in the property <c>KibamboColumn.Header</c>.</param>
        /// <param name="columnType">The value to assign in the property <c>KibamboColumn.ColumnType</c>.</param>
        /// <param name="headerColumnType">The value to assign in the property <c>KibamboColumn.HeaderColumnType</c>.</param>
        /// <summary lang="fr">
        /// Initialise un objet <c>KibamboColumn</c> en spécifiant le nom interne de la colonne, l'intitulé de la colonne, le type de la colonne, et l'intitulé du type de la colonne.
        /// </summary>
        /// <param name="name" lang="fr">Valeur à affecter dans la propriété <c>KibamboColumn.Name</c>.</param>
        /// <param name="header" lang="fr">Valeur à affecter dans la propriété <c>KibamboColumn.Header</c>.</param>
        /// <param name="columnType" lang="fr">Valeur à affecter dans la propriété <c>KibamboColumn.ColumnType</c>.</param>
        /// <param name="headerColumnType" lang="fr">Valeur à affecter dans la propriété <c>KibamboColumn.HeaderColumnType</c>.</param>
        public KibamboColumn(string name, string header, KibamboColumnType columnType, string headerColumnType) : this(name, header, columnType)
        {
            HeaderColumnType = headerColumnType;
        }

        /// <summary>
        /// Initializes a <c>KibamboColumn</c> object by specifying the column's internal name, column title, column type type, column type title, and an array of comparison operators to use for the column.
        /// </summary>
        /// <param name="name">The value to assign in the property <c>KibamboColumn.Name</c>.</param>
        /// <param name="header">The value to assign in the property <c>KibamboColumn.Header</c>.</param>
        /// <param name="columnType">The value to assign in the property <c>KibamboColumn.ColumnType</c>.</param>
        /// <param name="headerColumnType">The value to assign in the property <c>KibamboColumn.HeaderColumnType</c>.</param>
        /// <param name="operators">The value to assign in the property <c>KibamboColumn.Operators</c>.</param>
        /// <summary lang="fr">
        /// Initialise un objet <c>KibamboColumn</c> en spécifiant le nom interne de la colonne, l'intitulé de la colonne, le type de la colonne, l'intitulé du type de la colonne, et un tableau des opérateurs de comparaison à utiliser pour la colonne.
        /// </summary>
        /// <param name="name" lang="fr">Valeur à affecter dans la propriété <c>KibamboColumn.Name</c>.</param>
        /// <param name="header" lang="fr">Valeur à affecter dans la propriété <c>KibamboColumn.Header</c>.</param>
        /// <param name="columnType" lang="fr">Valeur à affecter dans la propriété <c>KibamboColumn.ColumnType</c>.</param>
        /// <param name="headerColumnType" lang="fr">Valeur à affecter dans la propriété <c>KibamboColumn.HeaderColumnType</c>.</param>
        /// <param name="operators" lang="fr">Valeur à affecter dans la propriété <c>KibamboColumn.Operators</c>.</param>
        public KibamboColumn(string name, string header, KibamboColumnType columnType, string headerColumnType, string[] operators)
            : this(name, header, columnType, headerColumnType)
        {
            Operators = operators;
        }

        #endregion

        #region méthodesPubliques 

        /// <summary>
        /// Returns the column title.
        /// </summary>
        /// <returns>A string of characters.</returns>
        /// <summary lang="fr">
        /// Renvoie l'intitulé de la colonne.
        /// </summary>
        /// <returns lang="fr">Une chaîne de caractères.</returns>
        public override string ToString()
        {
            return Header;
        }

        #endregion
    }
}
