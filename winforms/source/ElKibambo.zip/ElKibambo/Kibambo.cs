﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Resources;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace ElKibambo
{
    /// <summary>
    /// Specifies the type of column value.
    /// </summary>
    /// <summary lang="fr">
    /// Indique le type de valeur de la colonne.
    /// </summary>
    public enum KibamboColumnType
    {
        /// <summary>
        /// A character string.
        /// </summary>
        /// <summary lang="fr">
        /// Une chaîne de caractères.
        /// </summary>
        String = 5,

        /// <summary>
        /// A numeric value (integer, float, etc.).
        /// </summary>
        /// <summary lang="fr">
        /// Une valeur numérique (entier, flottant, etc.).
        /// </summary>
        Numeric = 10
    }

    /// <summary>
    /// Allows you to specify the type of comparison.
    /// </summary>
    /// <summary lang="fr">
    /// Permet de spécifier le type de comparaison.
    /// </summary>
    public enum KibamboComparisonType
    {
        /// <summary>
        /// Ordinal comparison of case-sensitive character strings.
        /// </summary>
        /// <summary lang="fr">
        /// Comparaison ordinale des chaînes de caractères respectant la casse. 
        /// </summary>
        CaseSensitive = 5,

        /// <summary>
        /// Case-insensitive ordinal comparison of character strings.
        /// </summary>
        /// <summary lang="fr">
        /// Comparaison ordinale des chaînes de caractères non sensible à la casse.
        /// </summary>
        IgnoreCase = 10,

        /// <summary>
        /// Comparison ignoring diacritics including mainly accents.
        /// </summary>
        /// <summary lang="fr">
        /// Comparaison ignorant les signes diacritiques dont principalement les accents.
        /// </summary>
        IgnoreDiacriticSigns = 15,

        /// <summary>
        /// Comparison ignoring diacritics and breakage.
        /// </summary>
        /// <summary lang="fr">
        /// Comparaison ignorant les signes diacritiques et la casse.
        /// </summary>
        IgnoreDiacriticSignsAndCase = 20
    }

    /// <summary>
    /// A function that returns nothing and receives as the only parameter an object of type <c>DataGridViewRow</c>.
    /// </summary>
    /// <param name="row">A <c>DataGridView</c> object that represents a row in a data grid.</param>
    /// <summary lang="fr">
    /// Fonction qui ne renvoie rien et qui reçoit comme seul paramètre un objet de type <c>DataGridViewRow</c>.
    /// </summary>
    /// <param name="row" lang="fr">Objet <c>DataGridView</c> répresentant une ligne d'une grille de données.</param>
    public delegate void KibamboDelegate(DataGridViewRow row);

    /// <summary>
    /// The main class of the library. It is thanks to her that the research is implemented.
    /// </summary>
    /// <summary lang="fr">
    /// Classe principale de la bibliothèque. C’est grâce à elle que la recherche est mise en œuvre.
    /// </summary>
    public class Kibambo
    {
        #region attributs 
        
        private List<DataGridViewRow> _rowsSatisfied;
        private List<DataGridViewRow> _rowsUnsatisfied;
        private DataGridView _dgvData;
        private DataGridView _dgvSearch;
        private KibamboColumn[] _columns;
        private KibamboComparisonType _comparisonType;
        private KibamboDelegate _searchhHandler;
        private KibamboDelegate _cancelSearchHandler;
        private bool _autoCompleteColumns;
        private string _titleField;
        private string _titleType;
        private string _titleOperator;
        private string _titleValue;

        #endregion

        #region propriétés

        /// <summary>
        /// Collection of rows that met the search criteria.
        /// </summary>
        /// <summary lang="fr">
        /// Collection des lignes ayant satisfait aux critères de recherche.
        /// </summary>
        public List<DataGridViewRow> RowsSatisfied
        {
            get
            {
                return _rowsSatisfied;
            }
        }

        /// <summary>
        /// A collection of rows that did not meet the search criteria.
        /// </summary>
        /// <summary lang="fr">
        /// Collection des lignes n'ayant pas satisfait aux critères de recherche.
        /// </summary>
        public List<DataGridViewRow> RowsUnsatisfied
        {
            get
            {
                return _rowsUnsatisfied;
            }
        }

        /// <summary>
        /// Delegate who will receive in turn each row that met the search criteria when running the <c>Kibambo.Search()</c> method.
        /// </summary>
        /// <summary lang="fr">
        /// Délégué qui recevra tour à tour chaque ligne ayant satisfait aux critères de recherche lors de l'exécution de la méthode <c>Kibambo.Search()</c>.
        /// </summary>
        public KibamboDelegate SearchHandler
        {
            get
            {
                return _searchhHandler;
            }

            set
            {
                _searchhHandler = value;
            }
        }

        /// <summary>
        /// Delegate who will receive in turn each line that did not meet the search criteria. The operation that will be performed when the <c>Kibambo.ShowAll()</c> method is executed.
        /// </summary>
        /// <summary lang="fr">
        /// Délégué qui recevra tour à tour chaque ligne n'ayant pas satisfait aux critères de recherche. Opération qui sera effectuée lors de l'exécution de la méthode <c>Kibambo.ShowAll()</c>.
        /// </summary>
        public KibamboDelegate CancelSearchHandler
        {
            get
            {
                return _cancelSearchHandler;
            }

            set
            {
                _cancelSearchHandler = value;
            }
        }

        /// <summary>
        /// Provides read and write access to <c>KibamboColumn</c> objects representing each column in the data grid.
        /// </summary>
        /// <summary lang="fr">
        /// Permet d’accéder en lecture comme en écriture aux objets <c>KibamboColumn</c> représentant chaque colonne de la grille de données.
        /// </summary>
        public KibamboColumn[] Columns
        {
            get
            {
                var ress = new ResourceManager("ElKibambo.strings", typeof(Kibambo).Assembly);

                if (_columns == null || _columns.Length == 0)
                {
                    if(_autoCompleteColumns == true)
                    {
                        var columns = new List<KibamboColumn>();
                        foreach (DataGridViewColumn dgvc in _dgvData.Columns)
                        {
                            columns.Add(new KibamboColumn(
                                name: dgvc.Name,
                                header: dgvc.HeaderText,
                                columnType: KibamboColumnType.String,
                                headerColumnType: ress.GetString("headerColumnTypeStr")
                            ));
                        }

                        Columns = columns.ToArray();
                    }
                    
                    else
                    {
                        throw new KibamboException(KibamboErrorCode.ColumnsNotSpecified);
                    }
                }

                else if ((_columns.Length < _dgvData.Columns.Count) && _autoCompleteColumns == true)
                {
                    var columns = new List<KibamboColumn>();

                    foreach (DataGridViewColumn dgvc in _dgvData.Columns)
                    {
                        bool colonneExistante = false;

                        foreach (KibamboColumn kc in _columns)
                        {
                            if (dgvc.Name == kc.Name)
                            {
                                if (kc.Header == null)
                                {
                                    kc.Header = dgvc.HeaderText;
                                }

                                columns.Add(kc);
                                colonneExistante = true;
                                break;
                            }
                        }

                        if (colonneExistante == false)
                        {
                            columns.Add(new KibamboColumn(
                                name: dgvc.Name,
                                header: dgvc.HeaderText,
                                columnType: KibamboColumnType.String,
                                headerColumnType: ress.GetString("headerColumnTypeStr")
                            ));
                        }
                    }

                    _columns = columns.ToArray();
                }

                return _columns;
            }

            set
            {
                if(value.Length > _dgvData.Columns.Count)
                {
                    throw new KibamboException(KibamboErrorCode.MoreColumnsThanDgvData);
                }

                _columns = value;

                foreach(KibamboColumn kc in _columns)
                {
                    bool colonneExistante = false;

                    foreach(DataGridViewColumn dgvc in _dgvData.Columns)
                    {
                        if (dgvc.Name == kc.Name)
                        {
                            colonneExistante = true;

                            if (kc.Header == null)
                            {
                                kc.Header = dgvc.HeaderText;
                            }

                            break;
                        }
                    }

                    if(colonneExistante == false)
                    {
                        throw new KibamboException(KibamboErrorCode.ColumnNotRecognized);
                    }
                }
            }
        }

        /// <summary>
        /// Allows you to specify the type of comparison to use during the search. 
        /// </summary>
        /// <summary lang="fr">
        /// Permet de spécifier le type de comparaison à utiliser lors de la recherche. 
        /// </summary>
        public KibamboComparisonType ComparisonType
        {
            get
            {
                return _comparisonType;
            }

            set
            {
                _comparisonType = value;
            }
        }

        /// <summary>
        /// Instructs El Kibambo to automatically complete or not the unspecified columns.
        /// </summary>
        /// <summary lang="fr">
        /// Indique à El Kibambo de compléter automatiquement ou non les colonnes non spécifiées.
        /// </summary>
        public bool AutoCompleteColumns
        {
            get
            {
                return _autoCompleteColumns;
            }

            set
            {
                _autoCompleteColumns = value;
            }
        }

        /// <summary>
        /// The string to display as the header for the first column of the search <c>DataGridView</c>.
        /// </summary>
        /// <summary lang="fr">
        /// Chaîne à afficher comme en-tête pour la première colonne du <c>DataGridView</c> de recherche.
        /// </summary>
        public string TitleField
        {
            get
            {
                if(_titleField == null)
                {
                    _titleField = new ResourceManager("ElKibambo.strings", typeof(Kibambo).Assembly).GetString("field");
                }

                return _titleField;
            }
            set
            {
                if(value == null || value.Trim() == string.Empty)
                {
                    throw new ArgumentException(new ResourceManager("ElKibambo.strings", typeof(Kibambo).Assembly).GetString("invalidValueField"));
                }

                _titleField = value;
            }
        }

        /// <summary>
        /// The string to display as the header for the second column of the search <c>DataGridView</c>.
        /// </summary>
        /// <summary lang="fr">
        /// Chaîne à afficher comme en-tête pour la deuxième colonne du <c>DataGridView</c> de recherche.
        /// </summary>
        public string TitleType
        {
            get
            {
                if (_titleType == null)
                {
                    _titleType = new ResourceManager("ElKibambo.strings", typeof(Kibambo).Assembly).GetString("type");
                }

                return _titleType;
            }

            set
            {
                if (value == null || value.Trim() == string.Empty)
                {
                    throw new ArgumentException(new ResourceManager("ElKibambo.strings", typeof(Kibambo).Assembly).GetString("invalidValueType"));
                }

                _titleType = value;
            }
        }

        /// <summary>
        /// The string to display as the header for the third column of the search <c>DataGridView</c>.
        /// </summary>
        /// <summary lang="fr">
        /// Chaîne à afficher comme en-tête pour la troisième colonne du <c>DataGridView</c> de recherche.
        /// </summary>
        public string TitleOperator
        {
            get
            {
                if (_titleOperator == null)
                {
                    _titleOperator = new ResourceManager("ElKibambo.strings", typeof(Kibambo).Assembly).GetString("comparisonOperator");
                }

                return _titleOperator;
            }
            set
            {
                if (value == null || value.Trim() == string.Empty)
                {
                    throw new ArgumentException(new ResourceManager("ElKibambo.strings", typeof(Kibambo).Assembly).GetString("invalidValueOperator"));
                }

                _titleOperator = value;
            }
        }

        /// <summary>
        /// The string to display as the header for the fourth column of the search <c>DataGridView</c>.
        /// </summary>
        /// <summary lang="fr">
        /// Chaîne à afficher comme en-tête pour la quatrième colonne du <c>DataGridView</c> de recherche.
        /// </summary>
        public string TitleValue
        {
            get
            {
                if (_titleValue == null)
                {
                    _titleValue = new ResourceManager("ElKibambo.strings", typeof(Kibambo).Assembly).GetString("value");
                }

                return _titleValue;
            }
            set
            {
                if (value == null || value.Trim() == string.Empty)
                {
                    throw new ArgumentException(new ResourceManager("ElKibambo.strings", typeof(Kibambo).Assembly).GetString("invalidValueValue"));
                }

                _titleValue = value;
            }
        }

        #endregion

        #region constructeurs

        /// <summary>
        /// Initializes a <c>Kibambo</c> object by specifying the grid containing the data, the grid that will be used to perform searches, and an optional parameter indicating whether you would like to automatically complete unspecified columns.
        /// </summary>
        /// <param name="dgvData">The <c>DataGridView</c> containing the data.</param>
        /// <param name="dgvSearch"><c>DataGridView</c> which will allow to set up the search functionalities.</param>
        /// <param name="autoCompleteColumns">Indicates whether we want El Kibambo to automatically complete or not the unspecified columns.</param>
        /// <summary lang="fr">
        /// Initialise un objet <c>Kibambo</c> en spécifiant la grille contenant les données, la grille qui permettra d'effectuer des recherches, et un paramètre optionel indiquant si on aimerait compléter automatiquement les colonnes non spécifiées.
        /// </summary>
        /// <param name="dgvData" lang="fr">Le <c>DataGridView</c> contenant les données.</param>
        /// <param name="dgvSearch" lang="fr"><c>DataGridView</c> qui va permettre de mettre en place les fonctionnalités de recherche.</param>
        /// <param name="autoCompleteColumns" lang="fr">Indique si nous voulons à ce qu’El Kibambo complète automatiquement ou non les colonnes non spécifiées.</param>
        public Kibambo(DataGridView dgvData, DataGridView dgvSearch, bool autoCompleteColumns = false)
        {
            if(dgvData == dgvSearch)
            {
                throw new KibamboException(KibamboErrorCode.DgvOfDataMustBeDifferentThanDgvOfSearch);
            }
            
            _dgvData = dgvData;
            _dgvSearch = dgvSearch;

            _autoCompleteColumns = autoCompleteColumns;
            _comparisonType = KibamboComparisonType.IgnoreDiacriticSignsAndCase;
        }

        /// <summary>
        /// Initializes a <c>Kibambo</c> object by specifying the grid containing the data, the grid that will be used to perform searches, a delegate that will receive all rows that have met the search criteria, and an optional parameter indicating whether you would like to automatically complete unspecified columns.
        /// </summary>
        /// <param name="dgvData">The <c>DataGridView</c> containing the data.</param>
        /// <param name="dgvSearch"><c>DataGridView</c> which will allow to set up the search functionalities.</param>
        /// <param name="searchHandler">Delegate to call during the search.</param>
        /// <param name="autoCompleteColumns">Indicates whether we want El Kibambo to automatically complete or not the unspecified columns.</param>
        /// <summary lang="fr">
        /// Initialise un objet <c>Kibambo</c> en spécifiant la grille contenant les données, la grille qui permettra d'effectuer des recherches, un délégue qui recevra toutes les lignes ayant satisfait aux critères de recherche, et un paramètre optionel indiquant si on aimerait compléter automatiquement les colonnes non spécifiées.
        /// </summary>
        /// <param name="dgvData" lang="fr">Le <c>DataGridView</c> contenant les données.</param>
        /// <param name="dgvSearch" lang="fr"><c>DataGridView</c> qui va permettre de mettre en place les fonctionnalités de recherche.</param>
        /// <param name="searchHandler" lang="fr">Délégué à appeler lors de la recherche.</param>
        /// <param name="autoCompleteColumns" lang="fr">Indique si nous voulons à ce qu’El Kibambo complète automatiquement ou non les colonnes non spécifiées.</param>
        public Kibambo(DataGridView dgvData, DataGridView dgvSearch, KibamboDelegate searchHandler, bool autoCompleteColumns = false) : this(dgvData, dgvSearch, autoCompleteColumns)
        {
            if (dgvData == dgvSearch)
            {
                throw new KibamboException(KibamboErrorCode.DgvOfDataMustBeDifferentThanDgvOfSearch);
            }

            SearchHandler = searchHandler;
        }

        /// <summary>
        /// Initializes a <c>Kibambo</c> object by specifying the grid containing the data, the grid that will be used to perform searches, an array of <c>KibamboColumn</c> objects, and an optional parameter indicating whether you would like to automatically complete unspecified columns.
        /// </summary>
        /// <param name="dgvData">The <c>DataGridView</c> containing the data.</param>
        /// <param name="dgvSearch"><c>DataGridView</c> which will allow to set up the search functionalities.</param>
        /// <param name="columns">An array of <c>KibamboColumn</c> objects that reference each column in the grid containing the data.</param>
        /// <param name="autoCompleteColumns">Indicates whether we want El Kibambo to automatically complete or not the unspecified columns.</param>
        /// <summary lang="fr">
        /// Initialise un objet <c>Kibambo</c> en spécifiant la grille contenant les données, la grille qui permettra d'effectuer des recherches, un tableau des objets <c>KibamboColumn</c> et un paramètre optionel indiquant si on aimerait compléter automatiquement les colonnes non spécifiées.
        /// </summary>
        /// <param name="dgvData" lang="fr">Le <c>DataGridView</c> contenant les données.</param>
        /// <param name="dgvSearch" lang="fr"><c>DataGridView</c> qui va permettre de mettre en place les fonctionnalités de recherche.</param>
        /// <param name="columns" lang="fr">Tableau d’objets <c>KibamboColumn</c> faisant référence à chaque colonne de la grille contenant les données.</param>
        /// <param name="autoCompleteColumns" lang="fr">Indique si nous voulons à ce qu’El Kibambo complète automatiquement ou non les colonnes non spécifiées.</param>
        public Kibambo(DataGridView dgvData, DataGridView dgvSearch, KibamboColumn[] columns, bool autoCompleteColumns = false)
        {
            if (dgvData == dgvSearch)
            {
                throw new KibamboException(KibamboErrorCode.DgvOfDataMustBeDifferentThanDgvOfSearch);
            }

            _dgvData = dgvData;
            _dgvSearch = dgvSearch;

            _autoCompleteColumns = autoCompleteColumns;
            _comparisonType = KibamboComparisonType.IgnoreDiacriticSignsAndCase;

            Columns = columns;
        }

        /// <summary>
        /// Initializes a <c>Kibambo</c> object by specifying the grid containing the data, the grid that will be used to perform searches, an array of <c>KibamboColumn</c> objects, a delegate that will receive all rows that have met the search criteria, and an optional parameter indicating whether you would like to automatically complete unspecified columns.
        /// </summary>
        /// <param name="dgvData">The <c>DataGridView</c> containing the data.</param>
        /// <param name="dgvSearch"><c>DataGridView</c> which will allow to set up the search functionalities.</param>
        /// <param name="columns">An array of <c>KibamboColumn</c> objects that reference each column in the grid containing the data.</param>
        /// <param name="searchHandler">Delegate to call during the search.</param>
        /// <param name="autoCompleteColumns">Indicates whether we want El Kibambo to automatically complete or not the unspecified columns.</param>
        /// <summary lang="fr">
        /// Initialise un objet <c>Kibambo</c> en spécifiant la grille contenant les données, la grille qui permettra d'effectuer des recherches, un tableau des objets <c>KibamboColumn</c>, un délégue qui recevra toutes les lignes ayant satisfait aux critères de recherche, et un paramètre optionel indiquant si on aimerait compléter automatiquement les colonnes non spécifiées.
        /// </summary>
        /// <param name="dgvData" lang="fr">Le <c>DataGridView</c> contenant les données.</param>
        /// <param name="dgvSearch" lang="fr"><c>DataGridView</c> qui va permettre de mettre en place les fonctionnalités de recherche.</param>
        /// <param name="columns" lang="fr">Tableau d’objets <c>KibamboColumn</c> faisant référence à chaque colonne de la grille contenant les données.</param>
        /// <param name="searchHandler" lang="fr">Délégué à appeler lors de la recherche.</param>
        /// <param name="autoCompleteColumns" lang="fr">Indique si nous voulons à ce qu’El Kibambo complète automatiquement ou non les colonnes non spécifiées.</param>
        public Kibambo(DataGridView dgvData, DataGridView dgvSearch, KibamboColumn[] columns, KibamboDelegate searchHandler, bool autoCompleteColumns = false) : this(dgvData, dgvSearch, columns, autoCompleteColumns)
        {
            if (dgvData == dgvSearch)
            {
                throw new KibamboException(KibamboErrorCode.DgvOfDataMustBeDifferentThanDgvOfSearch);
            }

            SearchHandler = searchHandler;
        }

        /// <summary>
        /// Initializes a <c>Kibambo</c> object by specifying the grid containing the data, the grid that will be used to perform searches, a delegate that will receive all rows that have met the search criteria, a delegate that will receive all rows that have not met the search criteria, and an optional parameter indicating whether you would like to automatically complete the unspecified columns.
        /// </summary>
        /// <param name="dgvData">The <c>DataGridView</c> containing the data.</param>
        /// <param name="dgvSearch"><c>DataGridView</c> which will allow to set up the search functionalities.</param>
        /// <param name="searchHandler">Delegate to call during the search.</param>
        /// <param name="cancelSearchHandler">Delegate who will be called when you want to cancel the search.</param>
        /// <param name="autoCompleteColumns">Indicates whether we want El Kibambo to automatically complete or not the unspecified columns.</param>
        /// <summary lang="fr">
        /// Initialise un objet <c>Kibambo</c> en spécifiant la grille contenant les données, la grille qui permettra d'effectuer des recherches, un délégue qui recevra toutes les lignes ayant satisfait aux critères de recherche, un délégue qui recevra toutes les lignes n'ayant pas satisfait aux critères de recherche, et un paramètre optionel indiquant si on aimerait compléter automatiquement les colonnes non spécifiées.
        /// </summary>
        /// <param name="dgvData" lang="fr">Le <c>DataGridView</c> contenant les données.</param>
        /// <param name="dgvSearch" lang="fr"><c>DataGridView</c> qui va permettre de mettre en place les fonctionnalités de recherche.</param>
        /// <param name="searchHandler" lang="fr">Délégué à appeler lors de la recherche.</param>
        /// <param name="cancelSearchHandler" lang="fr">Délégué qui sera appeler lorsqu'on voudra annuler la recherche.</param>
        /// <param name="autoCompleteColumns" lang="fr">Indique si nous voulons à ce qu’El Kibambo complète automatiquement ou non les colonnes non spécifiées.</param>
        public Kibambo(DataGridView dgvData, DataGridView dgvSearch, KibamboDelegate searchHandler, KibamboDelegate cancelSearchHandler, bool autoCompleteColumns = false)
            : this(dgvData, dgvSearch, searchHandler, autoCompleteColumns)
        {
            if (dgvData == dgvSearch)
            {
                throw new KibamboException(KibamboErrorCode.DgvOfDataMustBeDifferentThanDgvOfSearch);
            }

            CancelSearchHandler = cancelSearchHandler;
        }

        /// <summary>
        /// Initializes a <c>Kibambo</c> object by specifying the grid containing the data, the grid that will be used to perform searches, an array of <c>KibamboColumn</c> objects, a delegate that will receive all rows that have met the search criteria, a delegate that will receive all rows that have not met the search criteria, and an optional parameter indicating whether you would like to automatically complete unspecified columns.
        /// </summary>
        /// <param name="dgvData">The <c>DataGridView</c> containing the data.</param>
        /// <param name="dgvSearch"><c>DataGridView</c> which will allow to set up the search functionalities.</param>
        /// <param name="columns">An array of <c>KibamboColumn</c> objects that reference each column in the grid containing the data.</param>
        /// <param name="searchHandler">Delegate to call during the search.</param>
        /// <param name="cancelSearchHandler">Delegate who will be called when one wants to cancel the search.</param>
        /// <param name="autoCompleteColumns">Indicates whether we want El Kibambo to automatically complete or not the unspecified columns.</param>
        /// <summary lang="fr">
        /// Initialise un objet <c>Kibambo</c> en spécifiant la grille contenant les données, la grille qui permettra d'effectuer des recherches, un tableau des objets <c>KibamboColumn</c>, un délégue qui recevra toutes les lignes ayant satisfait aux critères de recherche, un délégue qui recevra toutes les lignes n'ayant pas satisfait aux critères de recherche, et un paramètre optionel indiquant si on aimerait compléter automatiquement les colonnes non spécifiées.
        /// </summary>
        /// <param name="dgvData" lang="fr">Le <c>DataGridView</c> contenant les données.</param>
        /// <param name="dgvSearch" lang="fr"><c>DataGridView</c> qui va permettre de mettre en place les fonctionnalités de recherche.</param>
        /// <param name="columns" lang="fr">Tableau d’objets <c>KibamboColumn</c> faisant référence à chaque colonne de la grille contenant les données.</param>
        /// <param name="searchHandler" lang="fr">Délégué à appeler lors de la recherche.</param>
        /// <param name="cancelSearchHandler" lang="fr">Délégué qui sera appeler losqu'on voudra annuler la recherche.</param>
        /// <param name="autoCompleteColumns" lang="fr">Indique si nous voulons à ce qu’El Kibambo complète automatiquement ou non les colonnes non spécifiées.</param>
        public Kibambo(DataGridView dgvData, DataGridView dgvSearch, KibamboColumn[] columns, KibamboDelegate searchHandler, KibamboDelegate cancelSearchHandler, bool autoCompleteColumns = false)
            : this(dgvData, dgvSearch, columns, searchHandler, autoCompleteColumns)
        {
            if (dgvData == dgvSearch)
            {
                throw new KibamboException(KibamboErrorCode.DgvOfDataMustBeDifferentThanDgvOfSearch);
            }

            CancelSearchHandler = cancelSearchHandler;
        }

        #endregion

        #region méthodesPubliques 

        /// <summary>
        /// Method called to initialize/reset El Kibambo. It is to be called just after building the Kibambo object or after modifying its properties.
        /// </summary>
        /// <summary lang="fr">
        /// Méthode appelée pour initialiser/réinitialiser El Kibambo. Elle est à appeler juste après avoir construit l’objet Kibambo ou après modification de ses propriétés.
        /// </summary>
        public void Initialize()
        {
            _dgvSearch.Columns.Add("field", TitleField);
            _dgvSearch.Columns.Add("type", TitleType);

            var dgvcbc = new DataGridViewComboBoxColumn();
            dgvcbc.HeaderText = TitleOperator;
            dgvcbc.Name = "cbbOperator";
            _dgvSearch.Columns.Add(dgvcbc);

            var dgvtbc = new DataGridViewTextBoxColumn();
            dgvtbc.HeaderText = TitleValue;
            dgvtbc.Name = "txtValue";
            _dgvSearch.Columns.Add(dgvtbc);

            _rowsUnsatisfied = new List<DataGridViewRow>();
            _rowsSatisfied = new List<DataGridViewRow>();

            ConfigureDgv();
            PeuplateWithColumns();
        }

        /// <summary>
        /// The method to call to initiate search operations.
        /// </summary>
        /// <summary lang="fr">
        /// Méthode à appeler pour lancer les opérations de recherche.
        /// </summary>
        public void Search()
        {
            /*
             * Nous parcourons la grille de recherche afin de trouver les lignes ou l'utilisateur a saisi une valeur
             * Les lignes repondant à la condition sont mises dans une collection
            */
            List<RowData> rowsData = new List<RowData>();
            foreach (DataGridViewRow row in _dgvSearch.Rows)
            {
                try
                {
                    if (row.Cells["cbbOperator"].Value.ToString().Trim() != "" && row.Cells["txtValue"].Value.ToString().Trim() != "")
                    {
                        rowsData.Add(new RowData()
                        {
                            Column = FindColumn(row.Cells[0].Value.ToString()),
                            Operator = row.Cells["cbbOperator"].Value.ToString(),
                            Value = row.Cells["txtValue"].Value.ToString()
                        });
                    }
                }
                catch (NullReferenceException)
                {
                    //throw ex;
                }
            }

            /*
             * ...
             */

            _dgvData.CurrentCell = null;

            // On (ré)initialise les lignes ayant et n'ayant pas satisfait à la condition
            _rowsUnsatisfied = new List<DataGridViewRow>();
            _rowsSatisfied = new List<DataGridViewRow>();

            for (var i = _dgvData.Rows.Count - 1; i >= 0; i--)
            {
                foreach (RowData rowData in rowsData)
                {
                    // il y a reference nulle si la cellule de valeur est vide
                    try
                    {
                        string valueData = _dgvData.Rows[i].Cells[rowData.Column.Name].Value.ToString();
                        string valueSearch = rowData.Value;

                        string comparisonOperator = rowData.Operator;
                        KibamboColumnType type = rowData.Column.ColumnType;

                        var result = false;

                        if (comparisonOperator == "LIKE")
                        {
                            result = Like(valueData, valueSearch);
                        }

                        else
                        {
                            if (type == KibamboColumnType.Numeric)
                            {
                                result = CheckForNumber(valueData, valueSearch, comparisonOperator);
                            }
                            else if (type == KibamboColumnType.String)
                            {
                                result = CheckForString(valueData, valueSearch, comparisonOperator);
                            }
                        }

                        // Si la ligne ne satisfait pas ...
                        if (result == false)
                        {
                            try
                            {
                                _rowsUnsatisfied.Add(_dgvData.Rows[i]);

                                if (SearchHandler != null)
                                {
                                    _dgvData.CurrentCell = null;
                                    _dgvData.Rows[i].Selected = false;

                                    SearchHandler(_dgvData.Rows[i]);
                                }

                                // Quand déjà une colonne de la ligne ne satisfait pas à la condition, inutile de tester les autres car la condition est un ET logique
                                break;
                            }
                            catch (Exception)
                            {
                                // throw ex;
                            }
                        }

                        // La ligne satisfait à la condition
                        else
                        {
                            try
                            {
                                _rowsSatisfied.Add(_dgvData.Rows[i]);
                            }

                            catch (Exception)
                            {
                                // throw ex
                            }
                        }
                    }
                    catch (NullReferenceException)
                    {
                    }
                }
            }
        }

        /// <summary>
        /// Method to call to cancel the search.
        /// </summary>
        /// <summary lang="fr">
        /// Méthode à appeler pour annuler la recherche.
        /// </summary>
        public void CancelSearch()
        {
            // Si la fonction de traitement evenementielle existe et que nous avons des lignes ayant satisfait à la condition
            if (CancelSearchHandler != null && RowsUnsatisfied.Count > 0)
            {
                foreach (var row in RowsUnsatisfied)
                {
                    CancelSearchHandler(row);
                }
            }

            RowsSatisfied.Clear();
            RowsUnsatisfied.Clear();
        }

        #endregion

        #region méthodesPrivées

        private void ConfigureDgv()
        {
            _dgvSearch.EditMode = DataGridViewEditMode.EditOnEnter;
            _dgvSearch.Columns[0].ReadOnly = true;
            _dgvSearch.Columns[0].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;

            _dgvSearch.Columns[1].ReadOnly = true;
            _dgvSearch.Columns[1].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;

            _dgvSearch.Columns[2].AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;

            _dgvSearch.Columns[3].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;

            _dgvSearch.RowHeadersVisible = false;
            _dgvSearch.AllowUserToAddRows = false;
            _dgvSearch.AllowUserToOrderColumns = false;
            _dgvSearch.AllowDrop = false;
            _dgvSearch.AllowUserToDeleteRows = false;
            _dgvSearch.AllowUserToResizeRows = false;
        }

        private KibamboColumn FindColumn(string columnHeader)
        {
            foreach (var column in _columns)
            {
                if (column.Header == columnHeader)
                {
                    return column;
                }
            }

            throw new KibamboException(KibamboErrorCode.ColumnNotRecognized);
        }
        
        private bool CheckForNumber(string valueDataStr, string valueSearchStr, string comparisonOperator)
        {
            // La valeur dans la grille de données
            double valueData;

            // La valeur dans la grille de recherche
            double valueSearch;

            try
            {
                valueData = double.Parse(valueDataStr);
                valueSearch = double.Parse(valueSearchStr);
            }

            catch (FormatException)
            {
                throw new KibamboException(KibamboErrorCode.ValueMustBeNumeric);
            }

            switch (comparisonOperator)
            {
                case "==":
                    return valueData == valueSearch;

                case "!=":
                    return valueData != valueSearch;

                case "<":
                    return valueData < valueSearch;

                case "<=":
                    return valueData <= valueSearch;

                case ">":
                    return valueData > valueSearch;

                case ">=":
                    return valueData >= valueSearch;

                default:
                    throw new KibamboException(KibamboErrorCode.OperatorNotRecognized);
            }
        }

        private bool CheckForString(string valueData, string valueSearch, string comparisonOperator)
        {
            int comp;
            switch (_comparisonType)
            {
                case KibamboComparisonType.CaseSensitive:
                    comp = string.Compare(valueSearch, valueData, StringComparison.Ordinal);
                    break;

                case KibamboComparisonType.IgnoreDiacriticSigns:
                    comp = string.Compare(valueSearch, valueData, CultureInfo.CurrentCulture, CompareOptions.IgnoreNonSpace);
                    break;

                case KibamboComparisonType.IgnoreDiacriticSignsAndCase:
                    comp = string.Compare(valueSearch, valueData, CultureInfo.CurrentCulture, CompareOptions.IgnoreNonSpace | CompareOptions.IgnoreCase);
                    break;

                case KibamboComparisonType.IgnoreCase:
                    comp = string.Compare(valueSearch, valueData, StringComparison.OrdinalIgnoreCase);
                    break;

                default: throw new KibamboException(KibamboErrorCode.ComparisonTypeNotRecognized);
            }

            // Pour rappel, Compare() renvoie :
            // 0 si les deux chaines sont egales, 
            // une valeur negative si la premiere est inferieure à la deuxieme, 
            // une valeur positive si la premiere est superieure à la deuxieme

            switch (comparisonOperator)
            {
                case "==":
                    return comp == 0 ? true : false;

                case "!=":
                    return comp != 0 ? true : false;

                case ">":
                    return comp > 0 ? true : false;

                case "<":
                    return comp < 0 ? true : false;

                case "<=":
                    return comp <= 0 ? true : false;

                case ">=":
                    return comp >= 0 ? true : false;

                default: throw new KibamboException(KibamboErrorCode.OperatorNotRecognized);
            }
        }

        private void PeuplateWithColumns()
        {
            _dgvSearch.Rows.Clear();

            var i = 0;
            foreach (var column in Columns)
            {
                _dgvSearch.Rows.Add(column.Header, column.HeaderColumnType);

                DataGridViewComboBoxCell comboBoxCell = (DataGridViewComboBoxCell)_dgvSearch.Rows[i].Cells["cbbOperator"];
                comboBoxCell.DataSource = column.Operators;
                comboBoxCell.Value = column.Operators[0];

                i++;
            }
        }

        private bool Like(string valueData, string valueSearch)
        {
            if (string.IsNullOrEmpty(valueData) || string.IsNullOrEmpty(valueSearch))
            {
                return false;
            }

            valueSearch = "%" + valueSearch + "%";
            var remplacementToken = "~~~~";

            string result = valueSearch.Replace("_", remplacementToken).Replace("%", ".*");
            result = Regex.Replace(result, @"\[.*" + remplacementToken + @".*\]", "_");
            result = result.Replace(remplacementToken, ".");

            Regex regex = new Regex("^" + result + "$", RegexOptions.IgnoreCase | RegexOptions.Singleline);

            if (regex.Matches(valueData).Count > 0)
            {
                return true;
            }

            return false;
        }

        #endregion

        private struct RowData
        {
            public KibamboColumn Column { get; set; }
            public string Operator { get; set; }
            public string Value { get; set; }
        }
    }
}
