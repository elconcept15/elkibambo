﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using ElKibambo;

namespace Test
{
    public partial class Form1 : Form
    {
        DataGridView dgvPersons;
        DataGridView dgvSearch;

        GroupBox gbSearch;

        Button btnShowAll;
        Button btnSearch;

        Kibambo kibambo;

        public Form1()
        {
            InitializeComponent();
            InitializeControls();
        }

        private void InitializeControls()
        {
            dgvPersons = new DataGridView();
            dgvSearch = new DataGridView();

            gbSearch = new GroupBox();

            btnShowAll = new Button();
            btnSearch = new Button();

            ((ISupportInitialize)(dgvPersons)).BeginInit();
            ((ISupportInitialize)(dgvSearch)).BeginInit();

            gbSearch.SuspendLayout();
            SuspendLayout();

            Controls.Clear();

            //
            // dgvcs1
            //
            var dgvcs1 = new DataGridViewCellStyle()
            {
                Alignment = DataGridViewContentAlignment.MiddleCenter,
                BackColor = SystemColors.Control,
                Font = new Font("Trebuchet MS", 9F, FontStyle.Bold, GraphicsUnit.Point, 0),
                ForeColor = SystemColors.WindowText,
                SelectionBackColor = SystemColors.Highlight,
                SelectionForeColor = SystemColors.HighlightText,
                WrapMode = DataGridViewTriState.True
            };

            //
            // dgvcs2
            //
            var dgvcs2 = new DataGridViewCellStyle()
            {
                Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point, 0)
            };

            //
            // dgvPersons
            //
            dgvPersons.AllowUserToAddRows = false;
            dgvPersons.AllowUserToDeleteRows = false;
            dgvPersons.AllowUserToResizeColumns = false;
            dgvPersons.AllowUserToResizeRows = false;
            dgvPersons.Anchor = ((AnchorStyles.Top | AnchorStyles.Bottom) | AnchorStyles.Left) | AnchorStyles.Right;
            dgvPersons.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvPersons.BackgroundColor = Color.White;
            dgvPersons.BorderStyle = BorderStyle.Fixed3D;
            dgvPersons.ColumnHeadersDefaultCellStyle = dgvcs1;
            dgvPersons.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvPersons.EditMode = DataGridViewEditMode.EditProgrammatically;
            dgvPersons.Location = new Point(12, 12);
            dgvPersons.MultiSelect = false;
            dgvPersons.RowHeadersVisible = false;
            dgvPersons.RowsDefaultCellStyle = dgvcs2;
            dgvPersons.ScrollBars = ScrollBars.Vertical;
            dgvPersons.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvPersons.Size = new Size(470, 358);
            dgvPersons.TabIndex = 0;

            //
            // dgvSearch
            //
            dgvSearch.Anchor = (AnchorStyles.Top | AnchorStyles.Left) | AnchorStyles.Right;
            dgvSearch.BackgroundColor = Color.White;
            dgvSearch.BorderStyle = BorderStyle.Fixed3D;
            dgvSearch.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvSearch.Location = new Point(10, 19);
            dgvSearch.Size = new Size(268, 111);
            dgvSearch.TabIndex = 1;

            //
            // btnShowAll
            //
            btnShowAll.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            btnShowAll.Location = new Point(106, 136);
            btnShowAll.Size = new Size(83, 23);
            btnShowAll.TabIndex = 3;
            btnShowAll.Text = "Show all";
            btnShowAll.UseVisualStyleBackColor = true;
            btnShowAll.Click += btnShowAll_Click;

            // 
            // btnSearch
            //
            btnSearch.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            btnSearch.Location = new Point(195, 136);
            btnSearch.Size = new Size(83, 23);
            btnSearch.TabIndex = 2;
            btnSearch.Text = "Search";
            btnSearch.UseVisualStyleBackColor = true;
            btnSearch.Click += btnSearch_Click;

            //
            // gbSearch
            //
            gbSearch.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            gbSearch.Controls.Add(btnShowAll);
            gbSearch.Controls.Add(btnSearch);
            gbSearch.Controls.Add(dgvSearch);
            gbSearch.Font = new Font("Segoe UI", 8.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            gbSearch.Location = new Point(490, 12);
            gbSearch.Size = new Size(286, 170);
            gbSearch.TabIndex = 2;
            gbSearch.TabStop = false;
            gbSearch.Text = "Research";

            //
            // Form1
            //
            AutoScaleDimensions = new SizeF(6F, 13F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(789, 385);
            Controls.Add(gbSearch);
            Controls.Add(dgvPersons);
            Text = "El Kibambo - Illustration";
            Load += new EventHandler(Form1_Load);
            StartPosition = FormStartPosition.CenterScreen;

            ((ISupportInitialize)(dgvPersons)).EndInit();
            ((ISupportInitialize)(dgvSearch)).EndInit();

            gbSearch.ResumeLayout(false);
            ResumeLayout(false);
        }

        private void InitializeDgvPersonnes()
        {
            // Ajout des colonnes 
            dgvPersons.Columns.Add("registration_number", "Reg. number");
            dgvPersons.Columns.Add("first_name", "First name");
            dgvPersons.Columns.Add("last_name", "Last name");
            dgvPersons.Columns.Add("age", "Age");

            // "Person" objects to display in the data grid
            var persons = new List<Person>
            {
                new Person("0001", "Michael", "Kyungu Ilunga", 21),
                new Person("0002", "Emmanuel", "Ilunga Ndalamba", 25),
                new Person("0003", "Jonathan", "Mulimbi Somwe", 22),
                new Person("0004", "Gloria", "Ngombe Kibambo", 20),
                new Person("0005", "Achille", "Mutombo Mubakilay", 22),
                new Person("0006", "Marc", "Kyalika Musomena", 23),
                new Person("0007", "Martin", "Manama Kabeya", 26),
                new Person("0008", "Ornellah", "Masengo Mutoni", 20),
                new Person("0009", "Elie", "Ebukeya Tshombe", 22),
                new Person("0010", "Françoise", "Ebukeya Lukonde", 15),
                new Person("0011", "Hansvané", "Kashala Kahilu", 23),
                new Person("0012", "Benoit", "Kamona Bunake", 23),
                new Person("0013", "Samuel", "Ngandu Mwepu", 21),
                new Person("0014", "Jules", "Malemo Miyayo", 23),
                new Person("0015", "Rachel", "Wany Mukanire", 23)
            };

            // Adding data in the data grid 
            foreach (Person person in persons)
            {
                dgvPersons.Rows.Add(
                    person.RegistrationNumber,
                    person.FirstName,
                    person.LastName,
                    person.Age
                );
            }
        }

        private void InitializeKibambo()
        {
            kibambo = new Kibambo(dgvPersons, dgvSearch, true)
            {
                Columns = new KibamboColumn[]
                {
                    new KibamboColumn("registration_number", KibamboColumnType.String)
                    {
                        Operators = new[] { "==", "!=" }
                    },

                    new KibamboColumn("age", "Age", KibamboColumnType.Numeric, "Entier", new string[] { "==", "<", ">", "<=", ">=", "!=" })
                },

                SearchHandler = delegate(DataGridViewRow row)
                {
                    // We choose to make the lines that have not satisfied the search criteria invisible.
                    // But you can nevertheless do something else, for example changing the color, etc.
                    row.Visible = false;
                },

                CancelSearchHandler = delegate(DataGridViewRow row)
                {
                    // As we have masked the lines that do not meet the search criteria during the research, it seems logical that we can re-display them when we want to cancel the search made.
                    // We must therefore put the line to its initial state before the search.
                    row.Visible = true;
                }
            };

            kibambo.Initialize();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            InitializeDgvPersonnes();
            InitializeKibambo();
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            try
            {
                kibambo.Search();
            }

            catch (KibamboException ex)
            {
                switch (ex.ErrorCode)
                {
                    case KibamboErrorCode.ValueMustBeNumeric:
                        MessageBox.Show("You must enter a digital type value for the digital column!", " Input error ", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        break;

                    default:
                        MessageBox.Show("An error occurred during the search. The error message is " + ex.Message + " !", " Error during search ", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        break;
                }
            }
        }

        private void btnShowAll_Click(object sender, EventArgs e)
        {
            kibambo.CancelSearch();
        }

        public class Person
        {
            public string RegistrationNumber { get; set; }
            public string FirstName { get; set; }
            public string LastName { get; set; }
            public int Age { get; set; }

            public Person(string registrationNumber, string firstName, string lastName, int age)
            {
                RegistrationNumber = registrationNumber;
                FirstName = firstName;
                LastName = lastName;
                Age = age;
            }
        }
    }
}
